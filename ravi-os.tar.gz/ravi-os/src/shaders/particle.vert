uniform float uTime;
uniform float uAssemble;   // 0..1 intro assembly
uniform float uBurst;      // 0..1 dispersion pulse on transition
uniform float uMotion;     // 0 = reduced motion
uniform float uSize;
uniform float uPixelRatio;
uniform vec2  uMouse;      // world-space xy at hologram plane
uniform float uRepel;
attribute vec3 aStart;
attribute vec4 aRand;      // x random, y size, z phase, w luminance
varying float vLum;
varying float vDepth;
varying float vMix;
varying float vAlpha;

void main() {
  float p = clamp(uAssemble * 1.5 - aRand.x * 0.5, 0.0, 1.0);
  p = p * p * (3.0 - 2.0 * p);
  vec3 pos = mix(aStart, position, p);

  // swirl while travelling in
  float sw = (1.0 - p) * 1.6 * aRand.x;
  float c = cos(sw), s = sin(sw);
  pos.xz = mat2(c, -s, s, c) * pos.xz;

  // idle motion
  float t = uTime * uMotion;
  pos += vec3(
    sin(t * 0.6 + aRand.z * 6.283),
    cos(t * 0.5 + aRand.z * 4.1),
    sin(t * 0.7 + aRand.z * 5.3)
  ) * 0.025;
  pos.z += sin(pos.y * 3.0 + t * 0.9) * 0.03 * p;
  pos.x += sin(pos.y * 2.0 + t * 0.5) * 0.015 * p;

  // dispersion burst
  vec3 dir = normalize(position + vec3(0.0001));
  pos += dir * uBurst * (0.6 + aRand.x * 2.2);

  vec4 wp = modelMatrix * vec4(pos, 1.0);

  // cursor repulsion (stateless; eases as the cursor moves)
  vec2 d = wp.xy - uMouse;
  float dist = length(d);
  float f = smoothstep(0.75, 0.0, dist) * uRepel;
  wp.xy += normalize(d + vec2(0.0001)) * f * 0.42;
  wp.z  += f * 0.35;

  vec4 mv = viewMatrix * wp;
  gl_Position = projectionMatrix * mv;

  float depthN = clamp((pos.z + 0.6) / 1.2, 0.0, 1.0);
  gl_PointSize = uSize * uPixelRatio * (0.55 + aRand.y) * (0.7 + depthN * 0.8) * (1.0 / -mv.z) * 3.2;
  vLum = aRand.w;
  vDepth = depthN;
  vMix = aRand.z;
  vAlpha = (0.35 + 0.65 * aRand.w) * (0.75 + 0.25 * sin(uTime * uMotion * 1.3 + aRand.z * 20.0)) * mix(0.25, 1.0, p);
}
