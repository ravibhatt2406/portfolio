precision highp float;
uniform float uDim;
varying float vLum;
varying float vDepth;
varying float vMix;
varying float vAlpha;

void main() {
  vec2 uv = gl_PointCoord - 0.5;
  float r = length(uv);
  if (r > 0.5) discard;
  float glow = pow(1.0 - r * 2.0, 1.6);

  vec3 violet = vec3(0.55, 0.36, 0.97);
  vec3 blue   = vec3(0.23, 0.51, 0.98);
  vec3 cyan   = vec3(0.13, 0.83, 0.93);
  vec3 white  = vec3(0.95, 0.96, 1.0);

  vec3 col = mix(violet, blue, vDepth);
  col = mix(col, cyan, smoothstep(0.78, 1.0, vMix) * 0.8);
  col = mix(col, white, smoothstep(0.55, 1.0, vLum) * 0.85);

  gl_FragColor = vec4(col * (0.8 + glow), glow * vAlpha * uDim);
}
