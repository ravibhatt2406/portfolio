export const skills: { group: string; items: string[] }[] = [
  { group: 'Programming', items: ['Java', 'Python', 'JavaScript', 'TypeScript', 'SQL'] },
  { group: 'Frontend', items: ['React', 'HTML', 'CSS', 'Tailwind CSS', 'shadcn/ui'] },
  { group: 'Backend', items: ['Node.js', 'NestJS'] },
  { group: 'AI / ML', items: ['Machine Learning', 'Deep Learning', 'Scikit-learn', 'TensorFlow', 'Pandas', 'NumPy'] },
  { group: 'Data', items: ['Power BI', 'Matplotlib', 'Excel', 'Jupyter Notebook'] },
  { group: 'Tools', items: ['Git', 'GitHub', 'VS Code'] },
]
