export const profile = {
  name: 'Ravi Bhatt',
  title: 'AI & Data Science Developer',
  tagline: 'Building intelligent solutions through AI and software development.',
  location: 'Udaipur, Rajasthan, India',
  degree: 'B.Tech in Artificial Intelligence and Data Science',
  college: 'Jaipur Engineering College and Research Centre, Jaipur',
  period: '2025–2029',
  links: {
    linkedin: 'https://linkedin.com/in/ravibhatt',
    github: 'https://github.com/ravibhatt2406',
  },
  // Add a real address to enable the mailto submission in the Contact app.
  email: '',
} as const
