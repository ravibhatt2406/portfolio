export const achievements: string[] = [
  'Participated in 10+ hackathons',
  'First place — Devpost FutureHacks',
  'First place with UrbanPlus.AI — FutureHacks Advanced',
  'SIH internal hackathon — 8th rank',
]
export const education = [
  { title: 'B.Tech, Artificial Intelligence & Data Science', org: 'Jaipur Engineering College and Research Centre, Jaipur', detail: '2025–2029' },
  { title: 'Class 12', org: 'Kendriya Vidyalaya No. 1, Udaipur', detail: '80.4%' },
  { title: 'Class 10', org: 'MGGS School', detail: '93.33%' },
  { title: 'JEE Main', org: '', detail: '92.16 percentile' },
]
