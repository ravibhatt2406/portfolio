export interface Experience { title: string; org?: string; period?: string; summary?: string }
// No dates or responsibilities were supplied — add them here when confirmed.
export const experience: Experience[] = [
  { title: 'Vicharanashala internship', org: 'IIT Ropar' },
  { title: 'Automobile development project', org: 'Freelance' },
  { title: 'Open-source contributions' },
]
