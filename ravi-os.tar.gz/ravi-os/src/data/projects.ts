export interface Project {
  name: string
  summary?: string // only filled when the facts are known
  tags?: string[]
  url?: string
}
// Only project names were supplied. Add summary/tags/url as they are confirmed.
export const projects: Project[] = [
  { name: 'Ecolens AI' },
  { name: 'UrbanPlus.AI', summary: 'First place at Devpost FutureHacks Advanced.' },
  { name: 'Plinth', summary: 'Site-aware house and floorplan planning tool, built for the United Hacks hackathon.' },
  { name: 'Alumni Management Platform' },
  { name: 'Car Price Prediction' },
  { name: 'Automobile Freelance Project' },
]
