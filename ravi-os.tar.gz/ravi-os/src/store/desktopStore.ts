import { create } from 'zustand'

export type AppId =
  | 'about' | 'projects' | 'skills' | 'experience'
  | 'achievements' | 'education' | 'resume' | 'contact' | 'terminal'

export type Phase = 'intro' | 'entering' | 'desktop'
export type Density = 'low' | 'medium' | 'high'

export interface WinState {
  open: boolean
  minimized: boolean
  maximized: boolean
  x: number; y: number; w: number; h: number
  z: number
}

interface DesktopState {
  phase: Phase
  windows: Record<AppId, WinState>
  zTop: number
  activeId: AppId | null
  density: Density
  reducedMotion: boolean
  setPhase: (p: Phase) => void
  replayIntro: () => void
  open: (id: AppId) => void
  close: (id: AppId) => void
  closeAll: () => void
  minimize: (id: AppId) => void
  minimizeAll: () => void
  toggleMax: (id: AppId) => void
  focus: (id: AppId) => void
  move: (id: AppId, x: number, y: number) => void
  resize: (id: AppId, w: number, h: number) => void
  setDensity: (d: Density) => void
  setReducedMotion: (v: boolean) => void
}

export const APP_IDS: AppId[] = [
  'about', 'projects', 'skills', 'experience', 'achievements', 'education', 'resume', 'contact', 'terminal',
]

const SIZES: Record<AppId, [number, number]> = {
  about: [560, 460], projects: [680, 500], skills: [620, 480], experience: [560, 420],
  achievements: [540, 400], education: [560, 440], resume: [620, 560], contact: [520, 520], terminal: [600, 400],
}

const blank = (id: AppId, i: number): WinState => ({
  open: false, minimized: false, maximized: false,
  x: 0, y: 0, w: SIZES[id][0], h: SIZES[id][1], z: i,
})

const initial = (): Record<AppId, WinState> =>
  Object.fromEntries(APP_IDS.map((id, i) => [id, blank(id, i)])) as Record<AppId, WinState>

const prefersReduced =
  typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

export const useDesktop = create<DesktopState>((set, get) => ({
  phase: 'intro',
  windows: initial(),
  zTop: 20,
  activeId: null,
  density: 'medium',
  reducedMotion: !!prefersReduced,

  setPhase: (phase) => set({ phase }),
  replayIntro: () => set({ phase: 'intro', windows: initial(), activeId: null }),

  open: (id) => {
    const { windows, zTop } = get()
    const w = windows[id]
    const z = zTop + 1
    let { x, y } = w
    if (!w.open) {
      // cascade new windows, centred in the work area
      const n = Object.values(windows).filter((v) => v.open).length
      const vw = window.innerWidth, vh = window.innerHeight
      x = Math.max(16, Math.round((vw - w.w) / 2 + 120 + n * 28 - 60))
      y = Math.max(44, Math.round((vh - w.h) / 2 - 20 + n * 24))
    }
    set({
      zTop: z, activeId: id,
      windows: { ...windows, [id]: { ...w, open: true, minimized: false, x, y, z } },
    })
  },
  close: (id) => set((s) => ({
    windows: { ...s.windows, [id]: { ...s.windows[id], open: false, minimized: false, maximized: false } },
    activeId: s.activeId === id ? null : s.activeId,
  })),
  closeAll: () => set({ windows: initial(), activeId: null }),
  minimize: (id) => set((s) => ({
    windows: { ...s.windows, [id]: { ...s.windows[id], minimized: true } },
    activeId: s.activeId === id ? null : s.activeId,
  })),
  minimizeAll: () => set((s) => ({
    windows: Object.fromEntries(
      Object.entries(s.windows).map(([k, v]) => [k, v.open ? { ...v, minimized: true } : v]),
    ) as Record<AppId, WinState>,
    activeId: null,
  })),
  toggleMax: (id) => set((s) => ({
    windows: { ...s.windows, [id]: { ...s.windows[id], maximized: !s.windows[id].maximized } },
  })),
  focus: (id) => {
    const { zTop, windows, activeId } = get()
    if (activeId === id && windows[id].z === zTop) return
    set({ zTop: zTop + 1, activeId: id, windows: { ...windows, [id]: { ...windows[id], z: zTop + 1 } } })
  },
  move: (id, x, y) => set((s) => ({ windows: { ...s.windows, [id]: { ...s.windows[id], x, y } } })),
  resize: (id, w, h) => set((s) => ({ windows: { ...s.windows, [id]: { ...s.windows[id], w, h } } })),
  setDensity: (density) => set({ density }),
  setReducedMotion: (reducedMotion) => set({ reducedMotion }),
}))
