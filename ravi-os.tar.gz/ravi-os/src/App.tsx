import { AnimatePresence } from 'framer-motion'
import { useMemo } from 'react'
import { HologramScene } from './components/hologram/HologramScene'
import { StaticHologram } from './components/hologram/StaticHologram'
import { IntroOverlay } from './components/intro/IntroOverlay'
import { Desktop } from './components/desktop/Desktop'
import { useDesktop } from './store/desktopStore'
import { useMousePosition } from './hooks/useMousePosition'
import { useReducedMotionSync } from './hooks/useReducedMotion'
import { useBreakpoint } from './hooks/useBreakpoint'

function hasWebGL() {
  try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')) } catch { return false }
}

export default function App() {
  const phase = useDesktop((s) => s.phase)
  const mouse = useMousePosition()
  const bp = useBreakpoint()
  const gl = useMemo(hasWebGL, [])
  useReducedMotionSync()

  return (
    <>
      <div className="wallpaper" />
      {gl ? <HologramScene mouse={mouse} /> : <StaticHologram />}
      <AnimatePresence>{phase === 'intro' && <IntroOverlay key="intro" />}</AnimatePresence>
      {phase === 'desktop' && <Desktop mouse={mouse} bp={bp} />}
    </>
  )
}
