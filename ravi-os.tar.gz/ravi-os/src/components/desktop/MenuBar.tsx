import { useEffect, useRef, useState } from 'react'
import { Settings, Maximize, Wifi } from 'lucide-react'
import { useDesktop, APP_IDS, type Density } from '../../store/desktopStore'
import { APPS } from '../applications/registry'

type Item = { label: string; run: () => void } | 'sep'

function Clock() {
  const [t, setT] = useState(new Date())
  useEffect(() => { const i = setInterval(() => setT(new Date()), 1000); return () => clearInterval(i) }, [])
  return (
    <span className="tabular-nums text-white/80">
      {t.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' })}&nbsp;&nbsp;
      {t.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
    </span>
  )
}

export function MenuBar({ compact }: { compact: boolean }) {
  const s = useDesktop()
  const [openMenu, setOpenMenu] = useState<string | null>(null)
  const [showSettings, setShowSettings] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fn = (e: PointerEvent) => { if (!ref.current?.contains(e.target as Node)) { setOpenMenu(null); setShowSettings(false) } }
    window.addEventListener('pointerdown', fn)
    return () => window.removeEventListener('pointerdown', fn)
  }, [])

  const fullscreen = () => document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen?.()
  const openWins = APP_IDS.filter((id) => s.windows[id].open)

  const menus: Record<string, Item[]> = {
    File: [
      { label: 'Open Resume', run: () => s.open('resume') },
      { label: 'Open Contact', run: () => s.open('contact') },
      'sep',
      { label: 'Close All Windows', run: s.closeAll },
    ],
    View: [
      { label: 'Toggle Full Screen', run: fullscreen },
      { label: 'Replay Intro', run: s.replayIntro },
    ],
    Window: [
      { label: 'Minimize All', run: s.minimizeAll },
      { label: 'Close All', run: s.closeAll },
      ...(openWins.length ? (['sep', ...openWins.map((id) => ({ label: APPS[id].title, run: () => s.open(id) }))] as Item[]) : []),
    ],
    Terminal: [{ label: 'Open Terminal', run: () => s.open('terminal') }],
    Help: [
      { label: 'About RAVI.OS', run: () => s.open('about') },
      { label: 'Contact Ravi', run: () => s.open('contact') },
    ],
  }

  return (
    <div ref={ref} className="glass-bar fixed inset-x-0 top-0 z-40 flex h-8 items-center justify-between border-b border-white/[0.06] px-3 text-[13px]">
      <div className="flex items-center gap-1">
        <span className="mr-2 flex items-center gap-2 font-display text-[13px] font-bold tracking-wide text-white">
          <span className="h-2.5 w-2.5 rounded-full bg-gradient-to-br from-violet-400 to-cyan-300 shadow-[0_0_10px_rgba(139,92,246,.9)]" />RAVI.OS
        </span>
        {!compact && Object.entries(menus).map(([name, items]) => (
          <div key={name} className="relative">
            <button
              onClick={() => setOpenMenu(openMenu === name ? null : name)}
              onMouseEnter={() => openMenu && setOpenMenu(name)}
              className={`rounded px-2.5 py-0.5 ${openMenu === name ? 'bg-white/15 text-white' : 'text-white/75 hover:bg-white/10'}`}
            >{name}</button>
            {openMenu === name && (
              <div className="glass absolute left-0 top-7 min-w-[190px] rounded-xl p-1.5">
                {items.map((it, i) => it === 'sep'
                  ? <div key={i} className="my-1 h-px bg-white/10" />
                  : <button key={it.label} onClick={() => { it.run(); setOpenMenu(null) }} className="block w-full rounded-md px-3 py-1.5 text-left text-white/85 hover:bg-violet-500/50">{it.label}</button>)}
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="relative flex items-center gap-3">
        <Wifi size={14} className="text-white/60" aria-hidden />
        <button onClick={fullscreen} aria-label="Toggle full screen" className="text-white/70 hover:text-white"><Maximize size={14} /></button>
        <button onClick={() => setShowSettings(!showSettings)} aria-label="Settings" className="text-white/70 hover:text-white"><Settings size={14} /></button>
        <Clock />
        {showSettings && (
          <div className="glass absolute right-0 top-8 w-64 rounded-xl p-4 text-white/85">
            <p className="mb-2 text-xs text-white/50">Particle density</p>
            <div className="mb-4 flex gap-1.5">
              {(['low', 'medium', 'high'] as Density[]).map((d) => (
                <button key={d} onClick={() => s.setDensity(d)} className={`flex-1 rounded-lg py-1.5 text-xs capitalize ${s.density === d ? 'bg-violet-500/70 text-white' : 'bg-white/8 hover:bg-white/15'}`}>{d}</button>
              ))}
            </div>
            <label className="flex cursor-pointer items-center justify-between text-sm">
              Reduce motion
              <input type="checkbox" checked={s.reducedMotion} onChange={(e) => s.setReducedMotion(e.target.checked)} className="h-4 w-4 accent-violet-500" />
            </label>
          </div>
        )}
      </div>
    </div>
  )
}
