import type { MutableRefObject } from 'react'
import { MapPin } from 'lucide-react'
import { MiniHologram } from '../hologram/HologramScene'
import { useDesktop } from '../../store/desktopStore'
import { APPS, NAV_ORDER } from '../applications/registry'
import { profile } from '../../data/profile'

export function Sidebar({ mouse, collapsed }: { mouse: MutableRefObject<{ x: number; y: number; active: boolean }>; collapsed: boolean }) {
  const open = useDesktop((s) => s.open)
  const winMap = useDesktop((s) => s.windows)
  const active = useDesktop((s) => s.activeId)

  return (
    <aside className={`glass fixed bottom-28 left-3 top-11 z-30 flex flex-col rounded-3xl ${collapsed ? 'w-[68px] items-center py-4' : 'w-[232px] p-4'}`}>
      <div className={`${collapsed ? 'h-11 w-11' : 'mx-auto h-28 w-28'} shrink-0`}><MiniHologram mouse={mouse} /></div>
      {!collapsed && (
        <div className="mt-2 text-center">
          <h2 className="font-display text-lg font-bold text-white">{profile.name}</h2>
          <p className="text-xs text-cyan-200/80">{profile.title}</p>
          <p className="mt-1.5 flex items-center justify-center gap-1 text-[11px] text-white/45"><MapPin size={11} />{profile.location}</p>
        </div>
      )}
      <nav className={`mt-4 flex min-h-0 flex-1 flex-col gap-0.5 overflow-y-auto ${collapsed ? 'items-center' : ''}`} aria-label="Applications">
        {NAV_ORDER.map((id) => {
          const { Icon, title } = APPS[id]
          const isOpen = winMap[id].open
          return (
            <button key={id} onClick={() => open(id)} title={title}
              className={`flex items-center gap-3 rounded-xl text-sm transition ${collapsed ? 'h-10 w-10 justify-center' : 'px-3 py-2'} ${active === id ? 'bg-violet-500/30 text-white' : 'text-white/70 hover:bg-white/10 hover:text-white'}`}>
              <Icon size={16} />
              {!collapsed && <span className="flex-1 text-left">{title}</span>}
              {!collapsed && isOpen && <span className="h-1.5 w-1.5 rounded-full bg-cyan-300" />}
            </button>
          )
        })}
      </nav>
    </aside>
  )
}
