import { useRef } from 'react'
import { motion, useMotionValue, useSpring, useTransform, type MotionValue } from 'framer-motion'
import { useDesktop, type AppId } from '../../store/desktopStore'
import { APPS, NAV_ORDER } from '../applications/registry'

const DOCK: AppId[] = [...NAV_ORDER, 'terminal']

function clickApp(id: AppId) {
  const { windows, activeId, open, minimize } = useDesktop.getState()
  const w = windows[id]
  if (w.open && !w.minimized && activeId === id) minimize(id)
  else open(id)
}

function DockIcon({ id, mouseX }: { id: AppId; mouseX: MotionValue<number> }) {
  const ref = useRef<HTMLButtonElement>(null)
  const w = useDesktop((s) => s.windows[id])
  const { Icon, gradient, title } = APPS[id]
  const dist = useTransform(mouseX, (v) => { const r = ref.current?.getBoundingClientRect(); return r ? v - (r.left + r.width / 2) : 999 })
  const size = useSpring(useTransform(dist, [-140, 0, 140], [50, 82, 50]), { mass: 0.1, stiffness: 180, damping: 14 })
  return (
    <div className="group relative flex flex-col items-center">
      <span className="pointer-events-none absolute -top-9 whitespace-nowrap rounded-lg bg-black/70 px-2.5 py-1 text-xs text-white opacity-0 backdrop-blur transition group-hover:opacity-100">{title}</span>
      <motion.button ref={ref} onClick={() => clickApp(id)} aria-label={title} style={{ width: size, height: size }}
        className={`flex items-center justify-center rounded-[22%] bg-gradient-to-br ${gradient} shadow-lg shadow-black/40 ring-1 ring-white/20`}
        whileTap={{ scale: 0.9 }}>
        <Icon className="h-1/2 w-1/2 text-white drop-shadow" />
      </motion.button>
      <span className={`mt-1.5 h-1 w-1 rounded-full ${w.open ? (w.minimized ? 'bg-white/40' : 'bg-cyan-300 shadow-[0_0_6px_#67e8f9]') : 'bg-transparent'}`} />
    </div>
  )
}

export function Dock({ mobile }: { mobile: boolean }) {
  const mouseX = useMotionValue(Infinity)
  const winMap = useDesktop((s) => s.windows)

  if (mobile) {
    return (
      <div className="glass fixed inset-x-2 bottom-2 z-40 flex gap-3 overflow-x-auto rounded-3xl px-3 py-2.5" style={{ paddingBottom: 'max(.6rem, env(safe-area-inset-bottom))' }}>
        {DOCK.map((id) => {
          const { Icon, gradient, title } = APPS[id]
          return (
            <button key={id} onClick={() => clickApp(id)} aria-label={title} className="flex shrink-0 flex-col items-center gap-1">
              <span className={`flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br ${gradient} ring-1 ring-white/20`}><Icon size={22} className="text-white" /></span>
              <span className={`h-1 w-1 rounded-full ${winMap[id].open ? 'bg-cyan-300' : 'bg-transparent'}`} />
            </button>
          )
        })}
      </div>
    )
  }
  return (
    <div className="fixed inset-x-0 bottom-3 z-40 flex justify-center">
      <div onMouseMove={(e) => mouseX.set(e.clientX)} onMouseLeave={() => mouseX.set(Infinity)}
        className="glass flex h-[74px] items-end gap-2.5 rounded-[28px] px-3 pb-2.5">
        {DOCK.map((id) => <DockIcon key={id} id={id} mouseX={mouseX} />)}
      </div>
    </div>
  )
}
