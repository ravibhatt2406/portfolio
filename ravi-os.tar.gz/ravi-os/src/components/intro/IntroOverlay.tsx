import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useDesktop } from '../../store/desktopStore'

export function IntroOverlay() {
  const setPhase = useDesktop((s) => s.setPhase)
  const reduced = useDesktop((s) => s.reducedMotion)
  const [step, setStep] = useState(reduced ? 3 : 0)

  useEffect(() => {
    if (reduced) return
    const t = [setTimeout(() => setStep(1), 3200), setTimeout(() => setStep(2), 4100), setTimeout(() => setStep(3), 4900)]
    return () => t.forEach(clearTimeout)
  }, [reduced])

  const enter = (fast = false) => {
    setPhase('entering')
    setTimeout(() => setPhase('desktop'), fast || reduced ? 350 : 1000)
  }

  return (
    <motion.div
      className="fixed inset-0 z-10 flex flex-col items-center justify-end pb-[11vh] text-center select-none touch-none"
      initial={{ opacity: 1 }} exit={{ opacity: 0, transition: { duration: 0.6 } }}
    >
      <button
        onClick={() => enter(true)}
        className="absolute right-5 top-5 rounded-full border border-white/15 px-4 py-1.5 text-xs text-white/60 transition hover:border-white/40 hover:text-white"
      >
        Skip intro
      </button>

      <div className="px-6">
        <motion.h1
          className="font-display text-[clamp(2rem,6.5vw,5rem)] font-bold leading-none tracking-tight text-white"
          initial={{ opacity: 0, filter: 'blur(14px)', y: 12 }}
          animate={step >= 1 ? { opacity: 1, filter: 'blur(0px)', y: 0 } : {}}
          transition={{ duration: 1.1, ease: [0.2, 0.7, 0.2, 1] }}
        >
          HELLO, I’M RAVI.
        </motion.h1>
        <motion.p
          className="mt-4 text-[clamp(.75rem,1.6vw,1.05rem)] font-light tracking-[0.35em] text-cyan-200/80"
          initial={{ opacity: 0 }} animate={step >= 2 ? { opacity: 1 } : {}} transition={{ duration: 1 }}
        >
          AI &amp; DATA SCIENCE DEVELOPER
        </motion.p>
        <motion.button
          onClick={() => enter()}
          className="mt-9 rounded-full border border-violet-300/40 bg-violet-500/10 px-8 py-3 text-sm font-semibold tracking-[0.25em] text-white shadow-[0_0_40px_-8px_rgba(139,92,246,.8)] backdrop-blur transition hover:bg-violet-500/25 hover:shadow-[0_0_60px_-6px_rgba(139,92,246,1)]"
          initial={{ opacity: 0, y: 8 }} animate={step >= 3 ? { opacity: 1, y: 0 } : {}}
          style={{ pointerEvents: step >= 3 ? 'auto' : 'none' }}
        >
          ENTER RAVI.OS
        </motion.button>
      </div>
    </motion.div>
  )
}
