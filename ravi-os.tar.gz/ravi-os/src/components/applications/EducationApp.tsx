import { education } from '../../data/achievements'
import { H, Row } from './ui'
export default function EducationApp() {
  return (
    <div className="p-7"><H>Education</H>
      <ul className="mt-3">{education.map((e) => <Row key={e.title} title={e.title} sub={e.org || undefined} meta={e.detail} />)}</ul>
    </div>
  )
}
