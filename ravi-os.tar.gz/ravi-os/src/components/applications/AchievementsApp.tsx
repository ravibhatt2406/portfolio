import { achievements } from '../../data/achievements'
import { H, Row } from './ui'
export default function AchievementsApp() {
  return (
    <div className="p-7"><H>Achievements</H>
      <ul className="mt-3">{achievements.map((a) => <Row key={a} title={a} />)}</ul>
    </div>
  )
}
