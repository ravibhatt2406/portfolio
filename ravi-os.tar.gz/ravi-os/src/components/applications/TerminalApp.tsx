import { useEffect, useRef, useState } from 'react'
import { profile } from '../../data/profile'
import { projects } from '../../data/projects'
import { skills } from '../../data/skills'
import { achievements } from '../../data/achievements'
import { useDesktop, APP_IDS, type AppId } from '../../store/desktopStore'

const HELP = 'Commands: whoami, projects, skills, achievements, open <app>, clear, help'

export default function TerminalApp() {
  const [lines, setLines] = useState<string[]>(['RAVI.OS terminal', HELP])
  const [val, setVal] = useState('')
  const end = useRef<HTMLDivElement>(null)
  useEffect(() => end.current?.scrollIntoView({ block: 'end' }), [lines])

  const run = (raw: string) => {
    const [cmd, ...rest] = raw.trim().split(/\s+/)
    let out: string[] = []
    switch (cmd) {
      case '': break
      case 'help': out = [HELP]; break
      case 'whoami': out = [`${profile.name} — ${profile.title}`, profile.location]; break
      case 'projects': out = projects.map((p) => '• ' + p.name); break
      case 'skills': out = skills.map((g) => `${g.group}: ${g.items.join(', ')}`); break
      case 'achievements': out = achievements.map((a) => '• ' + a); break
      case 'clear': setLines([]); return
      case 'open': {
        const id = rest[0] as AppId
        if (APP_IDS.includes(id)) { useDesktop.getState().open(id); out = [`opening ${id}…`] }
        else out = [`unknown app. try: ${APP_IDS.join(', ')}`]
        break
      }
      default: out = [`command not found: ${cmd}`]
    }
    setLines((l) => [...l, `$ ${raw}`, ...out])
  }

  return (
    <div className="h-full bg-black/40 p-4 font-mono text-[13px] leading-relaxed text-emerald-200/90" onClick={() => (document.getElementById('term-in') as HTMLInputElement | null)?.focus()}>
      {lines.map((l, i) => <div key={i} className="whitespace-pre-wrap">{l}</div>)}
      <form onSubmit={(e) => { e.preventDefault(); run(val); setVal('') }} className="flex gap-2">
        <span className="text-violet-300">$</span>
        <input id="term-in" autoFocus value={val} onChange={(e) => setVal(e.target.value)} className="flex-1 bg-transparent text-white outline-none" spellCheck={false} autoComplete="off" aria-label="Terminal input" />
      </form>
      <div ref={end} />
    </div>
  )
}
