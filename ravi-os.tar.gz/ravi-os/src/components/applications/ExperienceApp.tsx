import { experience } from '../../data/experience'
import { H, Row } from './ui'
export default function ExperienceApp() {
  return (
    <div className="p-7"><H>Experience</H>
      <ul className="mt-3">{experience.map((e) => <Row key={e.title} title={e.title} sub={e.org} meta={e.period} />)}</ul>
    </div>
  )
}
