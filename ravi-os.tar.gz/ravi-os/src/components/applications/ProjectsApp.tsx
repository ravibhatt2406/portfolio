import { ArrowUpRight } from 'lucide-react'
import { projects } from '../../data/projects'
import { H } from './ui'

export default function ProjectsApp() {
  return (
    <div className="p-7">
      <H>Projects</H>
      <ul className="mt-4">
        {projects.map((p) => (
          <li key={p.name} className="border-b border-white/[0.07] py-4 last:border-0">
            <div className="flex items-center justify-between gap-3">
              <p className="text-lg font-semibold text-white">{p.name}</p>
              {p.url && <a href={p.url} target="_blank" rel="noreferrer" aria-label={`Open ${p.name}`} className="text-cyan-300 hover:text-white"><ArrowUpRight size={18} /></a>}
            </div>
            {p.summary && <p className="mt-1 max-w-lg text-sm leading-relaxed text-white/60">{p.summary}</p>}
            {p.tags && <p className="mt-2 text-xs text-violet-200/70">{p.tags.join(', ')}</p>}
          </li>
        ))}
      </ul>
    </div>
  )
}
