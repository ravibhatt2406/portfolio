import { skills } from '../../data/skills'
import { H } from './ui'

export default function SkillsApp() {
  return (
    <div className="p-7">
      <H>Skills</H>
      <div className="mt-5 space-y-6">
        {skills.map((g) => (
          <section key={g.group}>
            <h3 className="mb-2.5 text-sm font-medium text-violet-200/80">{g.group}</h3>
            <div className="flex flex-wrap gap-2">
              {g.items.map((s) => (
                <span key={s} className="rounded-full border border-white/12 bg-white/[0.04] px-3.5 py-1.5 text-sm text-white/85">{s}</span>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  )
}
