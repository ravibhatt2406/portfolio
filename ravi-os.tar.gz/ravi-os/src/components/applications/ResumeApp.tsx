import { useEffect, useState } from 'react'
import { Download } from 'lucide-react'
import { H } from './ui'

const RESUME_URL = '/resume.pdf'

export default function ResumeApp() {
  const [exists, setExists] = useState<boolean | null>(null)
  useEffect(() => {
    fetch(RESUME_URL, { method: 'HEAD' })
      .then((r) => setExists(r.ok && (r.headers.get('content-type') || '').includes('pdf')))
      .catch(() => setExists(false))
  }, [])

  if (exists) {
    return (
      <div className="flex h-full flex-col">
        <div className="flex items-center justify-between p-5 pb-3"><H>Resume</H>
          <a href={RESUME_URL} download="Ravi-Bhatt-Resume.pdf" className="flex items-center gap-2 rounded-full bg-violet-500/80 px-4 py-1.5 text-sm font-medium text-white hover:bg-violet-500"><Download size={15} /> Download</a>
        </div>
        <iframe title="Resume" src={RESUME_URL} className="min-h-[360px] flex-1 border-0 bg-white/5" />
      </div>
    )
  }
  return (
    <div className="p-7"><H>Resume</H>
      <p className="mt-4 max-w-md leading-relaxed text-white/65">
        {exists === null ? 'Checking for a resume file…' : <>No resume file found. Place a PDF at <code className="rounded bg-white/10 px-1.5 py-0.5 text-cyan-200">public/resume.pdf</code> and it will appear here with a download button.</>}
      </p>
    </div>
  )
}
