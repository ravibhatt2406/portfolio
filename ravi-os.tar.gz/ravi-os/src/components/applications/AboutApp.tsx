import { profile } from '../../data/profile'
import portrait from '../../assets/portrait/portrait.jpg'
import { Github, Linkedin } from '../ui/BrandIcons'

export default function AboutApp() {
  return (
    <div className="flex flex-col gap-6 p-7 sm:flex-row">
      <img src={portrait} alt="Ravi Bhatt" className="h-32 w-32 shrink-0 rounded-full object-cover ring-1 ring-white/20" />
      <div>
        <h2 className="font-display text-3xl font-bold tracking-tight text-white">{profile.name}</h2>
        <p className="mt-1 text-cyan-200/85">{profile.title}</p>
        <p className="mt-4 max-w-md leading-relaxed text-white/70">{profile.tagline}</p>
        <dl className="mt-5 space-y-2 text-sm">
          <div><dt className="inline text-white/45">Based in </dt><dd className="inline text-white/90">{profile.location}</dd></div>
          <div><dt className="inline text-white/45">Studying </dt><dd className="inline text-white/90">{profile.degree}</dd></div>
          <div><dt className="inline text-white/45">At </dt><dd className="inline text-white/90">{profile.college}</dd></div>
        </dl>
        <div className="mt-6 flex gap-3">
          <a href={profile.links.github} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-full border border-white/15 px-4 py-1.5 text-sm text-white/80 hover:bg-white/10"><Github size={15} /> GitHub</a>
          <a href={profile.links.linkedin} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-full border border-white/15 px-4 py-1.5 text-sm text-white/80 hover:bg-white/10"><Linkedin size={15} /> LinkedIn</a>
        </div>
      </div>
    </div>
  )
}
