import { useState, type ChangeEvent, type FormEvent } from 'react'
import { Github, Linkedin } from '../ui/BrandIcons'
import { profile } from '../../data/profile'
import { H } from './ui'

const field = 'w-full rounded-xl border border-white/12 bg-white/[0.05] px-4 py-2.5 text-sm text-white placeholder:text-white/30 focus:border-violet-400/70 focus:outline-none'

export default function ContactApp() {
  const [v, setV] = useState({ name: '', email: '', message: '' })
  const [err, setErr] = useState<Partial<typeof v>>({})
  const [sent, setSent] = useState(false)
  const on = (k: keyof typeof v) => (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setV({ ...v, [k]: e.target.value })

  const submit = (e: FormEvent) => {
    e.preventDefault()
    const n: Partial<typeof v> = {}
    if (v.name.trim().length < 2) n.name = 'Enter your name.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) n.email = 'Enter a valid email address.'
    if (v.message.trim().length < 10) n.message = 'Write at least 10 characters.'
    setErr(n)
    if (Object.keys(n).length) return
    if (profile.email) {
      window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent('Hello from ' + v.name)}&body=${encodeURIComponent(v.message + '\n\n' + v.email)}`
    }
    setSent(true) // PLACEHOLDER: no backend — wire a real service here
  }

  return (
    <div className="p-7">
      <H>Contact</H>
      <div className="mt-3 flex gap-4 text-sm">
        <a href={profile.links.linkedin} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-cyan-200 hover:text-white"><Linkedin size={14} /> LinkedIn</a>
        <a href={profile.links.github} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-cyan-200 hover:text-white"><Github size={14} /> GitHub</a>
      </div>
      {sent ? (
        <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.04] p-5 text-sm leading-relaxed text-white/75">
          Message validated. {profile.email ? 'Your email app should open with the message ready to send.' : 'This form has no backend yet, so nothing was sent — use the LinkedIn or GitHub links above to reach Ravi.'}
          <button onClick={() => { setSent(false); setV({ name: '', email: '', message: '' }) }} className="mt-3 block text-cyan-200 hover:text-white">Write another message</button>
        </div>
      ) : (
        <form onSubmit={submit} noValidate className="mt-5 space-y-3.5">
          <label className="block"><span className="sr-only">Name</span><input className={field} placeholder="Your name" value={v.name} onChange={on('name')} aria-invalid={!!err.name} />{err.name && <p className="mt-1 text-xs text-rose-300">{err.name}</p>}</label>
          <label className="block"><span className="sr-only">Email</span><input className={field} placeholder="Your email" type="email" value={v.email} onChange={on('email')} aria-invalid={!!err.email} />{err.email && <p className="mt-1 text-xs text-rose-300">{err.email}</p>}</label>
          <label className="block"><span className="sr-only">Message</span><textarea className={field + ' min-h-[120px] resize-none'} placeholder="What would you like to talk about?" value={v.message} onChange={on('message')} aria-invalid={!!err.message} />{err.message && <p className="mt-1 text-xs text-rose-300">{err.message}</p>}</label>
          <button className="rounded-full bg-violet-500/85 px-6 py-2.5 text-sm font-semibold text-white hover:bg-violet-500">Send message</button>
        </form>
      )}
    </div>
  )
}
