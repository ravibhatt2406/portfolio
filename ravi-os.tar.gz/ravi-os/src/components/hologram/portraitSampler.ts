import portraitUrl from '../../assets/portrait/portrait.jpg'

export interface ParticleData {
  target: Float32Array // x,y,z per particle (assembled hologram)
  start: Float32Array  // x,y,z per particle (surrounding space)
  rand: Float32Array   // random, size, phase, luminance
  count: number
}

const RES = 192
const cache = new Map<number, Promise<ParticleData>>()

function boxBlur(src: Float32Array, w: number, h: number, r: number, passes: number) {
  let a = src.slice(), b = new Float32Array(src.length)
  for (let p = 0; p < passes; p++) {
    for (let y = 0; y < h; y++) {           // horizontal
      let acc = 0
      for (let x = -r; x <= r; x++) acc += a[y * w + Math.min(w - 1, Math.max(0, x))]
      for (let x = 0; x < w; x++) {
        b[y * w + x] = acc / (2 * r + 1)
        acc += a[y * w + Math.min(w - 1, x + r + 1)] - a[y * w + Math.max(0, x - r)]
      }
    }
    for (let x = 0; x < w; x++) {           // vertical
      let acc = 0
      for (let y = -r; y <= r; y++) acc += b[Math.min(h - 1, Math.max(0, y)) * w + x]
      for (let y = 0; y < h; y++) {
        a[y * w + x] = acc / (2 * r + 1)
        acc += b[Math.min(h - 1, y + r + 1) * w + x] - b[Math.max(0, y - r) * w + x]
      }
    }
  }
  return a
}

function load(): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const img = new Image()
    img.onload = () => res(img)
    img.onerror = rej
    img.src = portraitUrl
  })
}

/**
 * Portrait → blurred, abstract particle cloud.
 * 1. draw to an offscreen canvas  2. build a subject mask (distance from the backdrop colour,
 * inside the circular crop)  3. Gaussian-style blur (3 box passes)  4. rejection-sample particles
 * weighted by mask × luminance  5. add procedural depth (dome + luminance + noise).
 */
export function buildParticles(count: number): Promise<ParticleData> {
  const hit = cache.get(count)
  if (hit) return hit
  const p = load().then((img) => {
    const cv = document.createElement('canvas')
    cv.width = cv.height = RES
    const ctx = cv.getContext('2d', { willReadFrequently: true })!
    ctx.drawImage(img, 0, 0, RES, RES)
    const px = ctx.getImageData(0, 0, RES, RES).data
    const N = RES * RES

    // backdrop colour: patch of grey wall left of the head
    let br = 0, bg = 0, bb = 0, bn = 0
    for (let y = Math.floor(RES * 0.25); y < RES * 0.4; y++)
      for (let x = Math.floor(RES * 0.12); x < RES * 0.24; x++) {
        const i = (y * RES + x) * 4
        br += px[i]; bg += px[i + 1]; bb += px[i + 2]; bn++
      }
    br /= bn; bg /= bn; bb /= bn

    const mask = new Float32Array(N), lum = new Float32Array(N)
    for (let y = 0; y < RES; y++)
      for (let x = 0; x < RES; x++) {
        const i = y * RES + x
        const dx = x / RES - 0.5, dy = y / RES - 0.5
        const inside = Math.sqrt(dx * dx + dy * dy) < 0.455 ? 1 : 0
        const r = px[i * 4], g = px[i * 4 + 1], b = px[i * 4 + 2]
        const d = Math.sqrt((r - br) ** 2 + (g - bg) ** 2 + (b - bb) ** 2) / 255
        mask[i] = inside * Math.min(1, d * 3.2)
        lum[i] = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255
      }
    const m1 = boxBlur(mask, RES, RES, 3, 3)       // soft silhouette
    const mDome = boxBlur(mask, RES, RES, 10, 3)   // broad shape for volume
    const l1 = boxBlur(lum, RES, RES, 6, 3)        // blurred tone: face stays abstract

    const target = new Float32Array(count * 3)
    const start = new Float32Array(count * 3)
    const rand = new Float32Array(count * 4)
    let n = 0, guard = 0
    while (n < count && guard++ < count * 400) {
      const u = Math.random(), v = Math.random()
      const ix = Math.floor(u * RES), iy = Math.floor(v * RES)
      const i = iy * RES + ix
      const dens = Math.pow(Math.max(0, m1[i] - 0.12) / 0.88, 0.8) * (0.5 + 0.5 * Math.min(1, l1[i] * 1.6 + 0.25))
      if (Math.random() > dens) continue
      const S = 2.5
      const tone = Math.min(1, Math.max(0, (l1[i] - 0.1) * 1.5))
      target[n * 3] = (u - 0.5) * S + (Math.random() - 0.5) * 0.02
      target[n * 3 + 1] = (0.5 - v) * S + 0.1 + (Math.random() - 0.5) * 0.02
      target[n * 3 + 2] = mDome[i] * 0.55 + (tone - 0.4) * 0.35 + (Math.random() - 0.5) * 0.14 - 0.2
      // surrounding space
      const th = Math.random() * Math.PI * 2, ph = Math.acos(2 * Math.random() - 1)
      const rad = 3 + Math.random() * 4
      start[n * 3] = rad * Math.sin(ph) * Math.cos(th)
      start[n * 3 + 1] = rad * Math.sin(ph) * Math.sin(th) * 0.7
      start[n * 3 + 2] = rad * Math.cos(ph) - 1
      rand[n * 4] = Math.random()
      rand[n * 4 + 1] = Math.random()
      rand[n * 4 + 2] = Math.random()
      rand[n * 4 + 3] = tone
      n++
    }
    return { target: target.slice(0, n * 3), start: start.slice(0, n * 3), rand: rand.slice(0, n * 4), count: n }
  })
  cache.set(count, p)
  return p
}

export function particleCount(density: 'low' | 'medium' | 'high', mini = false): number {
  if (mini) return 3500
  const base = { low: 9000, medium: 20000, high: 32000 }[density]
  const w = typeof window !== 'undefined' ? window.innerWidth : 1280
  const cores = typeof navigator !== 'undefined' ? navigator.hardwareConcurrency || 8 : 8
  let k = w < 768 ? 0.4 : w < 1100 ? 0.65 : 1
  if (cores < 4) k *= 0.6
  return Math.round(base * k)
}
