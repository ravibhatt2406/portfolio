import { Suspense, useRef, type PointerEvent as RPE } from 'react'
import { motion } from 'framer-motion'
import { X, Minus, Plus } from 'lucide-react'
import { useDesktop, type AppId } from '../../store/desktopStore'
import { APPS } from '../applications/registry'
import type { Breakpoint } from '../../hooks/useBreakpoint'

export function Window({ id, bp }: { id: AppId; bp: Breakpoint }) {
  const w = useDesktop((s) => s.windows[id])
  const active = useDesktop((s) => s.activeId === id)
  const { close, minimize, toggleMax, focus, move, resize } = useDesktop.getState()
  const { title, Component } = APPS[id]
  const drag = useRef<{ dx: number; dy: number } | null>(null)
  const rs = useRef<{ x: number; y: number; w: number; h: number } | null>(null)
  const mobile = bp === 'mobile'
  const max = w.maximized || mobile

  const onDown = (e: RPE<HTMLDivElement>) => {
    focus(id)
    if (max || (e.target as HTMLElement).closest('button')) return
    drag.current = { dx: e.clientX - w.x, dy: e.clientY - w.y }
    e.currentTarget.setPointerCapture(e.pointerId)
  }
  const onMove = (e: RPE<HTMLDivElement>) => {
    if (!drag.current) return
    const x = Math.min(window.innerWidth - 90, Math.max(90 - w.w, e.clientX - drag.current.dx))
    const y = Math.min(window.innerHeight - 60, Math.max(34, e.clientY - drag.current.dy))
    move(id, x, y)
  }
  const onUp = () => { drag.current = null }

  const rDown = (e: RPE<HTMLDivElement>) => {
    e.stopPropagation(); focus(id)
    rs.current = { x: e.clientX, y: e.clientY, w: w.w, h: w.h }
    e.currentTarget.setPointerCapture(e.pointerId)
  }
  const rMove = (e: RPE<HTMLDivElement>) => {
    if (!rs.current) return
    resize(id, Math.max(360, rs.current.w + e.clientX - rs.current.x), Math.max(260, rs.current.h + e.clientY - rs.current.y))
  }

  const style = max
    ? { left: mobile ? 0 : 8, right: mobile ? 0 : 8, top: 32, bottom: mobile ? 78 : 96, zIndex: w.z }
    : { left: w.x, top: w.y, width: w.w, height: w.h, zIndex: w.z }

  return (
    <div className="absolute" style={style} onPointerDown={() => focus(id)}>
      <motion.div
        className={`glass flex h-full w-full flex-col overflow-hidden ${mobile ? 'rounded-t-2xl' : 'rounded-2xl'} ${active ? '' : 'opacity-90'}`}
        style={{ transformOrigin: '50% 100%', background: 'linear-gradient(160deg, rgba(22,16,48,.82), rgba(10,8,26,.78))' }}
        initial={{ opacity: 0, scale: 0.86, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.7, y: 120, transition: { duration: 0.22 } }}
        transition={{ type: 'spring', stiffness: 320, damping: 28 }}
        role="dialog" aria-label={title}
      >
        <div
          className="group relative flex h-11 shrink-0 cursor-default items-center border-b border-white/[0.07] px-4 touch-none"
          onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp}
          onDoubleClick={() => !mobile && toggleMax(id)}
        >
          <div className="flex gap-2">
            <button aria-label="Close" onClick={() => close(id)} className="flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#ff5f57] text-black/60"><X size={9} strokeWidth={3} className="opacity-0 group-hover:opacity-100" /></button>
            <button aria-label="Minimize" onClick={() => minimize(id)} className="flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#febc2e] text-black/60"><Minus size={9} strokeWidth={3} className="opacity-0 group-hover:opacity-100" /></button>
            <button aria-label="Maximize or restore" onClick={() => !mobile && toggleMax(id)} className="flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#28c840] text-black/60"><Plus size={9} strokeWidth={3} className="opacity-0 group-hover:opacity-100" /></button>
          </div>
          <span className="pointer-events-none absolute inset-x-0 text-center text-[13px] font-medium text-white/70">{title}</span>
        </div>
        <div className="window-body min-h-0 flex-1 overflow-auto">
          <Suspense fallback={<div className="p-7 text-sm text-white/40">Loading…</div>}><Component /></Suspense>
        </div>
        {!max && (
          <div onPointerDown={rDown} onPointerMove={rMove} onPointerUp={() => (rs.current = null)}
            className="absolute bottom-0 right-0 h-5 w-5 cursor-nwse-resize touch-none" aria-hidden />
        )}
      </motion.div>
    </div>
  )
}
