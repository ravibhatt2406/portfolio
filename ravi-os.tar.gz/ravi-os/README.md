# RAVI.OS
`npm install && npm run dev` — see CLAUDE_HANDOFF.md for architecture and status.
Drop a PDF at `public/resume.pdf` to enable the Resume app; set `email` in `src/data/profile.ts` to enable mailto in Contact.
