# Continuation prompt — RAVI.OS (paste into Antigravity or another coding agent)

You are continuing work on **RAVI.OS**, Ravi Bhatt's frontend-only portfolio. Read `CLAUDE_HANDOFF.md` in the project root first, then inspect the existing code before changing anything. Do not rewrite or restructure what exists; continue from the current state.

## Vision
1. Cinematic intro: black screen; ~20k GPU particles fly in and assemble into a deliberately blurry, abstract head-and-shoulders hologram generated from Ravi's portrait (white/violet/electric blue/cyan). Text: "HELLO, I’M RAVI." / "AI & DATA SCIENCE DEVELOPER", then "ENTER RAVI.OS" (plus Skip). Cursor rotates the hologram with inertia, repels nearby particles, and drives camera parallax.
2. Premium macOS-Sonoma-inspired desktop with an original cosmic look: top menu bar, floating profile sidebar with a live mini hologram, continuous particle environment, floating magnifying dock, and a real Zustand window manager (open/close/minimize/maximize/restore/drag/resize/focus) hosting eight apps: About Me, Projects, Skills, Experience, Achievements, Education, Resume, Contact.
3. Never a generic portfolio, cybersecurity/analytics dashboard, skill-percentage graphs, fake metrics or fake buttons. Frontend only. Never invent dates, URLs, contacts, awards.

## Already built (everything above is coded)
Stack: React 19 + TS + Vite + Tailwind v4 + Three/R3F + Framer Motion + Zustand + lucide-react. Particle engine (`src/components/hologram/*`, `src/shaders/*`), intro, desktop, window manager, nine apps (8 + Terminal), data files, responsive breakpoints, reduced-motion handling, no-WebGL fallback. `tsc -b` and `vite build` pass.

## NOT done / unverified
- Nothing has been viewed in a browser. Visual tuning of the hologram (size, brightness, density, mask quality, repulsion) is the first job.
- Interaction QA (drag/resize/minimize/dock restore/menus), mobile/tablet QA, performance check.
- Content gaps: project descriptions, experience dates, email, `public/resume.pdf`, project images, reference video look.

## Next phase: Phase 7 — QA, tuning, polish
1. `npm install && npm run dev`; verify intro → desktop transition and fix any runtime errors.
2. Tune `portraitSampler.ts` (mask threshold, density formula), `particle.vert/frag`, `ParticleHologram.tsx` until the hologram reads as a blurry human bust, not noise.
3. Test window manager and dock; test at ~390px, ~900px, ~1440px widths; test `prefers-reduced-motion`.
4. Reduce main bundle via manual chunks if desired.
Keep changes incremental, keep architecture, keep using local TypeScript data files. Run `npm run build` after each major change and update `CLAUDE_HANDOFF.md` (status, bugs, verification) when you finish.

## Commands
`npm install` · `npm run dev` (localhost:5173) · `npm run build` · `npm run preview`
