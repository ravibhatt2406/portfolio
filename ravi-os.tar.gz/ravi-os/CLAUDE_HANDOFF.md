# CLAUDE_HANDOFF.md — RAVI.OS

## 1. Project overview
RAVI.OS is Ravi Bhatt's frontend-only portfolio: (a) a cinematic particle-hologram intro built from his portrait (intentionally blurry/abstract), then (b) a macOS-inspired desktop (menu bar, floating profile sidebar, dock, real multi-window manager) with eight portfolio apps. No backend, DB or auth.
**Status: vertical slice complete (phases 1–6 coded; phase 7 partly). Type-checks and builds. NOT yet verified in a real browser.**

## 2. Completed work
- Hologram engine: offscreen-canvas portrait sampler (subject mask + 3-pass box blur ≈ Gaussian), rejection-sampled particles, procedural depth, custom GLSL (idle wave, swirl-in assembly, cursor repulsion, burst dispersion), spring-damped cursor rotation, camera parallax, separate star-dust layer.
- Intro: assemble → "HELLO, I’M RAVI." → subtitle → ENTER RAVI.OS; Skip intro button; same particle system persists into desktop (burst → re-form shifted right).
- Desktop: MenuBar (working File/View/Window/Terminal/Help menus, fullscreen, settings popover for density + reduce motion, live clock), floating Sidebar (mini live hologram, nav), Dock (hover magnification, active/minimized dots, click toggles minimize), hero text, 3 desktop shortcuts.
- Window manager (Zustand): open/close/minimize/maximize/restore, drag, bottom-right resize, focus + z-index, multiple windows, traffic lights. Mobile: windows are full-width sheets, bottom icon dock.
- Apps: About, Projects, Skills, Experience, Achievements, Education, Resume (iframe if /public/resume.pdf exists), Contact (validated form, placeholder submit), plus a small Terminal (extra 9th app, reachable from dock + Terminal menu).
- Data in `src/data/*.ts` — only facts supplied by Ravi; no invented dates/URLs/emails.

## 3. File structure
```
src/
  App.tsx, main.tsx, index.css (tokens, glass, wallpaper)
  components/
    hologram/ portraitSampler.ts  ParticleHologram.tsx  StarField.tsx  HologramScene.tsx (main + MiniHologram)  StaticHologram.tsx (no-WebGL fallback)
    intro/IntroOverlay.tsx
    desktop/ Desktop.tsx MenuBar.tsx Sidebar.tsx Dock.tsx
    windows/ Window.tsx WindowManager.tsx
    applications/ registry.tsx (AppId → title/icon/lazy component) + *App.tsx + ui.tsx
    ui/BrandIcons.tsx (inline GitHub/LinkedIn; lucide removed brand icons)
  store/desktopStore.ts   hooks/ useMousePosition useReducedMotion useBreakpoint
  data/ profile projects skills experience achievements(+education)
  shaders/particle.vert particle.frag
  assets/portrait/portrait.jpg
```

## 4. Technical implementation
React 19, TS, Vite 8, Tailwind v4 (@tailwindcss/vite), Three + @react-three/fiber 9, Framer Motion, Zustand, lucide-react. Not used: drei, GSAP, shadcn/ui (not needed yet).
- One full-screen `<Canvas>` lives behind intro and desktop. `ParticleHologram` reads the store with `getState()` inside `useFrame` — no React state per frame. Mouse is a ref (`useMousePosition`).
- Uniforms: uAssemble, uBurst, uMotion, uMouse, uRepel, uDim. Attributes: position (target), aStart, aRand(x random, y size, z phase, w tone).
- Particle count: density setting (9k/20k/32k) × viewport factor (mobile .4, tablet .65) × low-core factor. Mini sidebar hologram: 3.5k.
- Phase machine: `intro → entering (≈1s burst) → desktop`.
- Windows: store holds `{open, minimized, maximized, x,y,w,h,z}` per AppId; `WindowManager` renders open & non-minimized windows inside `AnimatePresence`.

## 5. Progress
Done: phases 1–6. Partial: phase 7 (responsive layout + reduced-motion + fallback coded, untested). Remaining: visual tuning, QA, content gaps.

## 6. Known bugs / risks (unverified)
- Never opened in a browser: tune particle size (`uSize`), brightness and density by eye. Subject mask threshold in `portraitSampler.ts` may need adjusting.
- Hair is dark → fewer particles there; head silhouette may look thin. Adjust the `dens` formula.
- Window drag updates the store every pointermove (fine for now; could move to transform + commit on release).
- Reduced motion: hologram static, assembly skipped. No dedicated static fallback beyond no-WebGL case.
- Mobile: touch rotation relies on pointermove while finger drags over the intro overlay (`touch-none`); desktop mobile view has no sidebar by design.
- Main bundle ≈1.3 MB (three). Consider manual chunking.
- Content gaps: project descriptions (except UrbanPlus.AI, Plinth), experience dates/roles, email, resume PDF, project images.
- Two WebGL contexts (main + sidebar mini).

## 7. How to run
```
npm install
npm run dev        # http://localhost:5173
npm run build      # tsc -b && vite build
npm run preview
```
No test suite yet.

## 8. Next steps
1. Run dev server; check intro assembly, hologram look, repulsion strength (`ParticleHologram.tsx`, `particle.vert`).
2. Tune sampler/colours (`portraitSampler.ts`, `particle.frag`).
3. Verify windows (drag/resize/min/max), dock restore, menus, mobile layout.
4. Add resume at `public/resume.pdf`; fill data files; set `profile.email`.
5. Optional: reference-video look (ask Ravi for the file), per-project detail views, manual chunking.
Decisions already made: single persistent canvas, Zustand window manager, no backend, no invented content.

## 9. Design decisions
Colours: void `#04030a`, violet `#8b5cf6`, electric `#3b82f6`, cyan `#22d3ee`, particle white `#f2f4ff`. Fonts: Syne (display), Manrope (UI). Glass panels with 28px blur; macOS traffic lights; dock magnification 50→82px. Hologram right-of-centre on desktop, hero copy bottom-left. No metrics, charts or skill percentages.

## 10. Assets
Present: `src/assets/portrait/portrait.jpg` (circular crop with grey backdrop; sampler masks the backdrop and ring). Missing: reference video (not supplied to this session), resume PDF, project images, wallpapers folder is empty.

## 11. Verification
`tsc -b` clean; `vite build` succeeds. Manually verified in browser: **nothing**. Not yet verified: all visuals, interactions, performance, mobile.
